"use client";
import { useEffect, useMemo, useState } from "react";
import { Prospect } from "@/types";
import LeadCard, { queueReason } from "@/components/LeadCard";

export default function QueuePage() {
  const [prospects, setProspects] = useState<Prospect[]>([]);
  const [region, setRegion] = useState("");

  useEffect(() => {
    fetch("/api/prospects").then((r) => r.json()).then(setProspects);
  }, []);

  const regions = useMemo(() => Array.from(new Set(prospects.map((p) => p.region).filter(Boolean))) as string[], [prospects]);

  const queue = useMemo(() => {
    const today = new Date().toISOString().slice(0, 10);
    const filtered = region ? prospects.filter((p) => p.region === region) : prospects;
    return filtered
      .filter((p) => queueReason(p) !== null || (p.next_followup_date && p.next_followup_date <= today))
      .sort((a, b) => {
        const rank = (p: Prospect) => {
          if (p.next_followup_date && p.next_followup_date < today) return 0;
          if (p.manually_prioritised) return 1;
          if (p.next_followup_date === today) return 2;
          return 3;
        };
        return rank(a) - rank(b);
      });
  }, [prospects, region]);

  return (
    <div className="p-4 md:p-8 space-y-6">
      <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-200 space-y-3">
        <h1 className="text-2xl font-black text-slate-900">Priority Calling Queue</h1>
        <p className="text-xs text-slate-500">Overdue follow-ups, renewals approaching, and manually prioritised leads — every entry shows why it's here.</p>
        <div className="flex gap-2 flex-wrap text-xs">
          <button onClick={() => setRegion("")} className={`px-2.5 py-1 rounded-lg font-bold ${region === "" ? "bg-slate-800 text-white" : "bg-slate-100 text-slate-600"}`}>All</button>
          {regions.map((r) => (
            <button key={r} onClick={() => setRegion(r)} className={`px-2.5 py-1 rounded-lg font-bold ${region === r ? "bg-blue-600 text-white" : "bg-slate-100 text-slate-600"}`}>{r}</button>
          ))}
        </div>
      </div>

      <div className="space-y-4">
        {queue.length === 0 && <p className="text-sm text-slate-500">Nothing due right now — queue is clear.</p>}
        {queue.map((p, i) => (
          <LeadCard key={p.id} p={p} index={i} />
        ))}
      </div>
    </div>
  );
}
