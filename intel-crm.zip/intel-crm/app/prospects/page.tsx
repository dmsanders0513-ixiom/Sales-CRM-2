"use client";
import { useEffect, useState, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { Prospect } from "@/types";
import LeadCard from "@/components/LeadCard";

function ProspectsInner() {
  const params = useSearchParams();
  const categoryParam = params.get("category") || "";
  const [prospects, setProspects] = useState<Prospect[]>([]);
  const [search, setSearch] = useState("");

  useEffect(() => {
    const qs = new URLSearchParams();
    if (categoryParam) qs.set("category", categoryParam);
    if (search) qs.set("search", search);
    fetch(`/api/prospects?${qs.toString()}`).then((r) => r.json()).then(setProspects);
  }, [categoryParam, search]);

  return (
    <div className="p-4 md:p-8 space-y-6">
      <div className="flex justify-between items-center flex-wrap gap-3">
        <h1 className="text-2xl font-black text-slate-900">{categoryParam || "All"} Prospects</h1>
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search company, contact, phone, email…"
          className="border border-slate-300 rounded-xl px-3 py-2 text-sm w-72 max-w-full"
        />
      </div>
      <div className="space-y-4">
        {prospects.length === 0 && <p className="text-sm text-slate-500">No prospects found.</p>}
        {prospects.map((p) => <LeadCard key={p.id} p={p} />)}
      </div>
    </div>
  );
}

export default function ProspectsPage() {
  return (
    <Suspense>
      <ProspectsInner />
    </Suspense>
  );
}
