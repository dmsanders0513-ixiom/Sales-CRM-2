"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { Prospect, Discovery, AgentRun } from "@/types";

export default function Dashboard() {
  const [prospects, setProspects] = useState<Prospect[]>([]);
  const [discoveries, setDiscoveries] = useState<Discovery[]>([]);
  const [runs, setRuns] = useState<AgentRun[]>([]);

  useEffect(() => {
    fetch("/api/prospects").then((r) => r.json()).then(setProspects);
    fetch("/api/inbox").then((r) => r.json()).then(setDiscoveries);
    fetch("/api/agent/run").then((r) => r.json()).then(setRuns);
  }, []);

  const today = new Date().toISOString().slice(0, 10);
  const todaysCalls = prospects.filter((p) => p.next_followup_date === today).length;
  const overdue = prospects.filter((p) => p.next_followup_date && p.next_followup_date < today).length;
  const newDiscoveries = discoveries.filter((d) => d.status === "NEW").length;
  const qualified = discoveries.filter((d) => d.status === "QUALIFIED").length;
  const meetings = prospects.filter((p) => p.sales_stage === "Meeting Booked").length;
  const proposals = prospects.filter((p) => p.sales_stage === "Proposal Sent").length;
  const won = prospects.filter((p) => p.sales_stage === "Won").length;
  const lost = prospects.filter((p) => p.sales_stage === "Lost").length;
  const lastRun = runs[0];

  const stat = (label: string, value: number | string, color = "text-slate-900") => (
    <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-200">
      <p className="text-xs font-bold text-slate-500 uppercase tracking-wide">{label}</p>
      <p className={`text-3xl font-black mt-1 ${color}`}>{value}</p>
    </div>
  );

  return (
    <div className="p-4 md:p-8 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-black text-slate-900">Dashboard</h1>
        <Link href="/agent" className="bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-2 rounded-xl text-sm font-bold">
          Deploy AI Agent →
        </Link>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {stat("Today's Calls", todaysCalls, "text-blue-600")}
        {stat("Overdue Follow-ups", overdue, "text-red-600")}
        {stat("New AI Discoveries", newDiscoveries, "text-amber-600")}
        {stat("Qualified Discoveries", qualified, "text-emerald-600")}
        {stat("Meetings Booked", meetings)}
        {stat("Proposals Sent", proposals)}
        {stat("Won", won, "text-emerald-600")}
        {stat("Lost", lost, "text-red-500")}
      </div>

      <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-200">
        <h2 className="font-black text-lg mb-3">AI Agent Status</h2>
        {lastRun ? (
          <div className="text-sm space-y-1 text-slate-700">
            <p>Last run: <span className="font-bold">{new Date(lastRun.started_at).toLocaleString()}</span> — status: <span className="font-bold">{lastRun.status}</span></p>
            <p>Target: {lastRun.target_category} / {lastRun.target_region} — {lastRun.leads_qualified} qualified of {lastRun.candidates_deep_researched} deep-researched ({lastRun.candidates_found} candidates found, {lastRun.searches_performed} searches).</p>
          </div>
        ) : (
          <p className="text-sm text-slate-500">No agent runs yet. Head to the Live AI Agent tab to deploy your first prospecting run.</p>
        )}
        <p className="text-xs text-slate-400 mt-2">
          Next scheduled run: requires a configured Vercel Cron job — see README.md §17 Automation.
        </p>
      </div>
    </div>
  );
}
