import { NextRequest, NextResponse } from "next/server";
import { getServiceClient } from "@/lib/supabase";

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  const supabase = getServiceClient();
  const { data: prospect, error } = await supabase.from("prospects").select("*").eq("id", params.id).single();
  if (error) return NextResponse.json({ error: error.message }, { status: 404 });

  const { data: activities } = await supabase
    .from("activities")
    .select("*")
    .eq("prospect_id", params.id)
    .order("created_at", { ascending: false });

  return NextResponse.json({ ...prospect, activities: activities || [] });
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const supabase = getServiceClient();
  const body = await req.json();

  const { data: before } = await supabase.from("prospects").select("sales_stage, next_followup_date").eq("id", params.id).single();

  const { data, error } = await supabase.from("prospects").update(body).eq("id", params.id).select().single();
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  // Auto-log meaningful changes to the timeline
  if (body.sales_stage && before && body.sales_stage !== before.sales_stage) {
    await supabase.from("activities").insert({
      prospect_id: params.id,
      activity_type: "stage_change",
      notes: `Stage changed from ${before.sales_stage} to ${body.sales_stage}.`,
    });
  }
  if (body._followupUpdate) {
    await supabase.from("activities").insert({
      prospect_id: params.id,
      activity_type: body._followupUpdate.followup_type ? "call" : "note",
      followup_type: body._followupUpdate.followup_type,
      outcome: body._followupUpdate.outcome,
      notes: body._followupUpdate.notes,
    });
  }

  return NextResponse.json(data);
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  const supabase = getServiceClient();
  const { error } = await supabase.from("prospects").delete().eq("id", params.id);
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ deleted: true });
}
