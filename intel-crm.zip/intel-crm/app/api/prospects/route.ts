import { NextRequest, NextResponse } from "next/server";
import { getServiceClient } from "@/lib/supabase";

export async function GET(req: NextRequest) {
  const supabase = getServiceClient();
  const category = req.nextUrl.searchParams.get("category");
  const region = req.nextUrl.searchParams.get("region");
  const search = req.nextUrl.searchParams.get("search");

  let query = supabase.from("prospects").select("*").order("next_followup_date", { ascending: true, nullsFirst: false });
  if (category) query = query.eq("category", category);
  if (region) query = query.eq("region", region);
  if (search) {
    query = query.or(
      `company_name.ilike.%${search}%,decision_maker_name.ilike.%${search}%,website.ilike.%${search}%,telephone.ilike.%${search}%,general_email.ilike.%${search}%,industry.ilike.%${search}%,notes.ilike.%${search}%`
    );
  }

  const { data, error } = await query;
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json(data);
}

export async function POST(req: NextRequest) {
  const supabase = getServiceClient();
  const body = await req.json();

  if (!body.company_name || !body.category) {
    return NextResponse.json({ error: "company_name and category are required." }, { status: 400 });
  }

  const { data, error } = await supabase.from("prospects").insert({ ...body, source: body.source || "Manual" }).select().single();
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  await supabase.from("activities").insert({
    prospect_id: data.id,
    activity_type: "note",
    notes: "Prospect created manually.",
  });

  return NextResponse.json(data, { status: 201 });
}
