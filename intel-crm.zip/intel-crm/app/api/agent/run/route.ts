import { NextRequest, NextResponse } from "next/server";
import { getServiceClient } from "@/lib/supabase";
import { getAIProvider } from "@/lib/ai";

export const maxDuration = 300; // this pipeline makes several sequential Gemini calls

/**
 * POST /api/agent/run
 * Body: { category, region, industry, companySizeBand, leadCount }
 *
 * Executes the full staged prospecting pipeline server-side (Gemini key
 * never touches the browser), logs progress to agent_runs, and writes
 * qualified leads to `discoveries` — never directly to `prospects`.
 */
export async function POST(req: NextRequest) {
  const body = await req.json();
  const { category, region, industry, companySizeBand, leadCount } = body;

  if (!category || !region || !industry || !companySizeBand || !leadCount) {
    return NextResponse.json({ error: "Missing required agent parameters." }, { status: 400 });
  }

  const supabase = getServiceClient();
  const maxSearches = Number(process.env.AGENT_MAX_DISCOVERY_SEARCHES || 6);
  const maxDeepResearch = Number(process.env.AGENT_MAX_DEEP_RESEARCH || 10);

  // Agent memory: don't re-research companies already known to us.
  const { data: memory } = await supabase.from("company_research_memory").select("company_name_normalized");
  const { data: existingProspects } = await supabase.from("prospects").select("company_name");
  const { data: existingDiscoveries } = await supabase.from("discoveries").select("company_name");
  const knownCompanyNames = [
    ...(memory || []).map((m) => m.company_name_normalized),
    ...(existingProspects || []).map((p) => p.company_name),
    ...(existingDiscoveries || []).map((d) => d.company_name),
  ];

  const { data: run, error: runError } = await supabase
    .from("agent_runs")
    .insert({
      target_category: category,
      target_region: region,
      target_industry: industry,
      target_company_size: companySizeBand,
      requested_lead_count: leadCount,
      status: "running",
    })
    .select()
    .single();

  if (runError || !run) {
    return NextResponse.json({ error: "Failed to create agent run record.", detail: runError?.message }, { status: 500 });
  }

  const logEntries: { ts: string; message: string }[] = [];
  const flushLog = async () => {
    await supabase.from("agent_runs").update({ log: logEntries }).eq("id", run.id);
  };

  try {
    const provider = getAIProvider();
    const result = await provider.runProspectingPipeline({
      category,
      region,
      industry,
      companySizeBand,
      leadCount: Number(leadCount),
      maxSearches,
      maxDeepResearch,
      knownCompanyNames,
      onLog: async (message: string) => {
        logEntries.push({ ts: new Date().toISOString(), message });
        await flushLog();
      },
    });

    // Insert qualified leads into the Inbox (discoveries), not prospects.
    const rows = result.leads.map((lead) => ({
      company_name: lead.companyName,
      industry: lead.industry,
      category: lead.category,
      region: lead.region,
      website: lead.website,
      address: lead.location,
      company_size_estimate: lead.companySize,
      decision_maker_name: lead.decisionMaker.name,
      decision_maker_title: lead.decisionMaker.title,
      decision_maker_contact: lead.decisionMaker.email || lead.decisionMaker.phone,
      decision_maker_verification: lead.decisionMaker.verificationStatus,
      lead_reason: lead.leadReason,
      trigger_signal: lead.triggerSignal,
      verified_fields: lead.verified,
      research_completeness: lead.researchConfidence,
      sales_relevance: lead.salesRelevance,
      verified_facts: lead.verifiedFacts,
      inferences: lead.inferences,
      sources: lead.sources,
      status: "NEW",
      agent_run_id: run.id,
    }));

    let inserted: any[] = [];
    if (rows.length > 0) {
      const { data, error } = await supabase.from("discoveries").insert(rows).select();
      if (error) throw error;
      inserted = data || [];

      // Log a discovery_created activity per new record + update research memory
      for (const d of inserted) {
        await supabase.from("activities").insert({
          discovery_id: d.id,
          activity_type: "discovery_created",
          notes: `AI agent run — qualified via ${category}/${region} pipeline.`,
        });
      }
      for (const lead of result.leads) {
        await supabase.from("company_research_memory").upsert(
          {
            company_name_normalized: lead.companyName.toLowerCase().trim(),
            website: lead.website,
            sources: lead.sources,
            findings: { leadReason: lead.leadReason, researchConfidence: lead.researchConfidence },
          },
          { onConflict: "company_name_normalized" }
        );
      }
    }

    await supabase
      .from("agent_runs")
      .update({
        status: "completed",
        searches_performed: result.searchesPerformed,
        candidates_found: result.candidatesFound,
        candidates_deep_researched: result.candidatesDeepResearched,
        leads_qualified: inserted.length,
        finished_at: new Date().toISOString(),
      })
      .eq("id", run.id);

    return NextResponse.json({ runId: run.id, leads: inserted, log: logEntries });
  } catch (err: any) {
    logEntries.push({ ts: new Date().toISOString(), message: `ERROR: ${err.message}` });
    await supabase.from("agent_runs").update({ status: "failed", log: logEntries, finished_at: new Date().toISOString() }).eq("id", run.id);
    return NextResponse.json({ error: "Agent run failed.", detail: err.message, log: logEntries }, { status: 500 });
  }
}

/** GET /api/agent/run?runId=... — poll a run's status/log (used if you move this to background execution). */
export async function GET(req: NextRequest) {
  const runId = req.nextUrl.searchParams.get("runId");
  const supabase = getServiceClient();
  if (runId) {
    const { data, error } = await supabase.from("agent_runs").select("*").eq("id", runId).single();
    if (error) return NextResponse.json({ error: error.message }, { status: 404 });
    return NextResponse.json(data);
  }
  const { data } = await supabase.from("agent_runs").select("*").order("started_at", { ascending: false }).limit(20);
  return NextResponse.json(data || []);
}
