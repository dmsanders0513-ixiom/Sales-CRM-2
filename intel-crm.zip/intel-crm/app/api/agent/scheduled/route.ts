import { NextRequest, NextResponse } from "next/server";

/**
 * GET /api/agent/scheduled
 * Wired to Vercel Cron (see vercel.json). Runs headless — no browser
 * needs to be open. Configure the sectors/regions to auto-prospect via
 * the AGENT_SCHEDULE_JOBS env var (JSON array) or edit the default below.
 *
 * Vercel Cron calls this with an Authorization: Bearer <CRON_SECRET> header
 * automatically when CRON_SECRET is set in project env vars.
 */
export async function GET(req: NextRequest) {
  const auth = req.headers.get("authorization");
  if (auth !== `Bearer ${process.env.CRON_SECRET}`) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const jobs = JSON.parse(
    process.env.AGENT_SCHEDULE_JOBS ||
      '[{"category":"SME","region":"Pretoria","industry":"Any","companySizeBand":"50-200","leadCount":10}]'
  );

  const origin = req.nextUrl.origin;
  const results = [];
  for (const job of jobs) {
    const res = await fetch(`${origin}/api/agent/run`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(job),
    });
    results.push({ job, status: res.status, body: await res.json() });
  }

  // TODO: wire up a notification (email/Slack webhook) here once you
  // decide on a notification channel — documented in README.md.
  return NextResponse.json({ ranJobs: jobs.length, results });
}
