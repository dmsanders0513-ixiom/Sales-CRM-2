import { NextRequest, NextResponse } from "next/server";
import { getServiceClient } from "@/lib/supabase";

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  const supabase = getServiceClient();
  const { data, error } = await supabase.from("discoveries").select("*").eq("id", params.id).single();
  if (error) return NextResponse.json({ error: error.message }, { status: 404 });
  const { data: activities } = await supabase.from("activities").select("*").eq("discovery_id", params.id).order("created_at", { ascending: false });
  return NextResponse.json({ ...data, activities: activities || [] });
}

/**
 * PATCH body: { action: "promote" | "reject" | "duplicate" | "edit", ...fields }
 * "promote" copies the discovery into `prospects` (human-approved), and
 * marks the discovery PROMOTED. This is the only path from Inbox -> CRM —
 * the agent itself never writes to `prospects`.
 */
export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const supabase = getServiceClient();
  const body = await req.json();

  if (body.action === "promote") {
    const { data: discovery, error: fetchErr } = await supabase.from("discoveries").select("*").eq("id", params.id).single();
    if (fetchErr || !discovery) return NextResponse.json({ error: "Discovery not found." }, { status: 404 });

    const { data: prospect, error: insertErr } = await supabase
      .from("prospects")
      .insert({
        company_name: discovery.company_name,
        category: discovery.category,
        industry: discovery.industry,
        region: discovery.region,
        address: discovery.address,
        website: discovery.website,
        decision_maker_name: discovery.decision_maker_name,
        decision_maker_title: discovery.decision_maker_title,
        decision_maker_email: discovery.decision_maker_verification !== "UNKNOWN" ? discovery.decision_maker_contact : null,
        source: "AI Agent",
        lead_reason: discovery.lead_reason,
        sales_stage: "New",
        discovery_id: discovery.id,
      })
      .select()
      .single();
    if (insertErr) return NextResponse.json({ error: insertErr.message }, { status: 500 });

    await supabase.from("discoveries").update({ status: "PROMOTED" }).eq("id", params.id);
    await supabase.from("activities").insert([
      { discovery_id: params.id, activity_type: "promoted", notes: `Promoted to CRM as prospect ${prospect.id}.` },
      { prospect_id: prospect.id, activity_type: "discovery_created", notes: "Created via promotion from AI discovery." },
    ]);

    return NextResponse.json({ discoveryStatus: "PROMOTED", prospect });
  }

  if (body.action === "reject") {
    const { data, error } = await supabase.from("discoveries").update({ status: "REJECTED" }).eq("id", params.id).select().single();
    if (error) return NextResponse.json({ error: error.message }, { status: 500 });
    await supabase.from("activities").insert({ discovery_id: params.id, activity_type: "rejected", notes: body.reason || "Rejected by user." });
    return NextResponse.json(data);
  }

  if (body.action === "duplicate") {
    const { data, error } = await supabase.from("discoveries").update({ status: "DUPLICATE" }).eq("id", params.id).select().single();
    if (error) return NextResponse.json({ error: error.message }, { status: 500 });
    return NextResponse.json(data);
  }

  // generic edit / note / status update
  const { action, ...fields } = body;
  const { data, error } = await supabase.from("discoveries").update(fields).eq("id", params.id).select().single();
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  if (fields.ai_notes) {
    await supabase.from("activities").insert({ discovery_id: params.id, activity_type: "note", notes: fields.ai_notes });
  }
  return NextResponse.json(data);
}
