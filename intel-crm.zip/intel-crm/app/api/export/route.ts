import { NextRequest, NextResponse } from "next/server";
import Papa from "papaparse";
import { getServiceClient } from "@/lib/supabase";

/** GET /api/export?type=prospects|discoveries|queue&category=&region= */
export async function GET(req: NextRequest) {
  const supabase = getServiceClient();
  const type = req.nextUrl.searchParams.get("type") || "prospects";
  const category = req.nextUrl.searchParams.get("category");
  const region = req.nextUrl.searchParams.get("region");

  const table = type === "discoveries" ? "discoveries" : "prospects";
  let query = supabase.from(table).select("*");
  if (category) query = query.eq("category", category);
  if (region) query = query.eq("region", region);
  if (type === "queue") {
    const today = new Date().toISOString().slice(0, 10);
    query = query.lte("next_followup_date", today);
  }

  const { data, error } = await query;
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  const csv = Papa.unparse(data || []);
  return new NextResponse(csv, {
    headers: {
      "Content-Type": "text/csv",
      "Content-Disposition": `attachment; filename="${type}-export-${new Date().toISOString().slice(0, 10)}.csv"`,
    },
  });
}
