import { NextRequest, NextResponse } from "next/server";
import Papa from "papaparse";
import { getServiceClient } from "@/lib/supabase";
import { findPotentialDuplicates, DedupeRecord } from "@/lib/dedupe";

/**
 * POST /api/csv-import
 * mode "preview": parses CSV text, returns detected columns + first rows
 *   + a suggested column mapping, WITHOUT writing anything.
 * mode "confirm": takes { rows, mapping }, checks each row against
 *   existing prospects for duplicates, inserts non-duplicates, and
 *   returns a report — flagged duplicates are NOT imported automatically,
 *   they're returned for the user to resolve via /api/dedupe.
 */
export async function POST(req: NextRequest) {
  const body = await req.json();
  const supabase = getServiceClient();

  if (body.mode === "preview") {
    const parsed = Papa.parse(body.csvText, { header: true, skipEmptyLines: true });
    const columns = parsed.meta.fields || [];
    const suggestedMapping = suggestMapping(columns);
    return NextResponse.json({
      columns,
      previewRows: parsed.data.slice(0, 10),
      totalRows: parsed.data.length,
      suggestedMapping,
      errors: parsed.errors,
    });
  }

  if (body.mode === "confirm") {
    const { rows, mapping, category } = body as { rows: Record<string, string>[]; mapping: Record<string, string>; category: string };

    const { data: existing } = await supabase.from("prospects").select("id, company_name, website, telephone, general_email, decision_maker_email");
    const existingRecords: DedupeRecord[] = existing || [];

    const toInsert: any[] = [];
    const flaggedDuplicates: any[] = [];

    rows.forEach((row, idx) => {
      const mapped = mapRow(row, mapping);
      if (!mapped.company_name) return; // skip rows with no company name

      const candidate: DedupeRecord = { id: `csv-${idx}`, ...mapped };
      const matches = findPotentialDuplicates(candidate, existingRecords);
      if (matches.length > 0) {
        flaggedDuplicates.push({ row: mapped, matches });
      } else {
        toInsert.push({ ...mapped, category: category || "SME", source: "CSV Import", sales_stage: "New" });
      }
    });

    let inserted: any[] = [];
    if (toInsert.length > 0) {
      const { data, error } = await supabase.from("prospects").insert(toInsert).select();
      if (error) return NextResponse.json({ error: error.message }, { status: 500 });
      inserted = data || [];
    }

    return NextResponse.json({
      importedCount: inserted.length,
      skippedAsDuplicate: flaggedDuplicates.length,
      flaggedDuplicates,
    });
  }

  return NextResponse.json({ error: "mode must be 'preview' or 'confirm'." }, { status: 400 });
}

function suggestMapping(columns: string[]): Record<string, string> {
  const map: Record<string, string> = {};
  const patterns: Record<string, RegExp> = {
    company_name: /company|business|organi[sz]ation|name/i,
    website: /website|url|site/i,
    telephone: /phone|tel|mobile|cell/i,
    general_email: /^email$|general.?email|info.?email/i,
    decision_maker_name: /contact.?name|decision.?maker|dm.?name/i,
    decision_maker_title: /title|position|role/i,
    decision_maker_email: /contact.?email|dm.?email/i,
    address: /address|location/i,
    region: /region|city|area/i,
    industry: /industry|sector/i,
  };
  for (const col of columns) {
    for (const [field, re] of Object.entries(patterns)) {
      if (re.test(col) && !Object.values(map).includes(col)) {
        map[field] = col;
        break;
      }
    }
  }
  return map;
}

function mapRow(row: Record<string, string>, mapping: Record<string, string>) {
  const out: Record<string, string | null> = {};
  for (const [field, column] of Object.entries(mapping)) {
    out[field] = row[column]?.trim() || null;
  }
  return out as any;
}
