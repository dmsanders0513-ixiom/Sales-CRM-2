"use client";
import { useEffect, useState } from "react";
import { Discovery } from "@/types";

export default function InboxPage() {
  const [discoveries, setDiscoveries] = useState<Discovery[]>([]);
  const [statusFilter, setStatusFilter] = useState("NEW");

  async function load() {
    const url = statusFilter ? `/api/inbox?status=${statusFilter}` : "/api/inbox";
    const data = await fetch(url).then((r) => r.json());
    setDiscoveries(data);
  }

  useEffect(() => { load(); }, [statusFilter]);

  async function act(id: string, action: string) {
    await fetch(`/api/inbox/${id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action }) });
    load();
  }

  const statuses = ["NEW", "REVIEW", "QUALIFIED", "REJECTED", "PROMOTED", "DUPLICATE"];

  return (
    <div className="p-4 md:p-8 space-y-6">
      <div className="flex justify-between items-center flex-wrap gap-3">
        <h1 className="text-2xl font-black text-slate-900">Inbox / Discovered Leads</h1>
        <div className="flex gap-1 flex-wrap text-xs">
          {statuses.map((s) => (
            <button key={s} onClick={() => setStatusFilter(s)} className={`px-2.5 py-1 rounded-lg font-bold ${statusFilter === s ? "bg-amber-500 text-white" : "bg-slate-100 text-slate-600"}`}>{s}</button>
          ))}
        </div>
      </div>

      <div className="space-y-4">
        {discoveries.length === 0 && <p className="text-sm text-slate-500">No discoveries in this status.</p>}
        {discoveries.map((d) => (
          <div key={d.id} className="bg-white p-5 rounded-2xl shadow-sm border border-slate-200 space-y-3">
            <div className="flex justify-between items-start flex-wrap gap-2">
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="text-lg font-black">{d.company_name}</h3>
                  <span className="bg-slate-100 text-slate-600 text-xs px-2 py-1 rounded font-bold">{d.category} · {d.industry || "—"}</span>
                  <span className="bg-blue-100 text-blue-700 text-xs px-2 py-1 rounded font-bold">{d.status}</span>
                </div>
                <p className="text-xs text-slate-500">{d.region} · discovered {new Date(d.date_discovered).toLocaleDateString()}</p>
              </div>
              {d.status === "NEW" || d.status === "REVIEW" ? (
                <div className="flex gap-2">
                  <button onClick={() => act(d.id, "promote")} className="bg-emerald-600 text-white px-3 py-1.5 rounded-lg text-xs font-bold">Promote to CRM</button>
                  <button onClick={() => act(d.id, "reject")} className="bg-red-100 text-red-700 px-3 py-1.5 rounded-lg text-xs font-bold">Reject</button>
                  <button onClick={() => act(d.id, "duplicate")} className="bg-slate-100 text-slate-600 px-3 py-1.5 rounded-lg text-xs font-bold">Mark Duplicate</button>
                </div>
              ) : null}
            </div>

            <div className="grid md:grid-cols-3 gap-3 text-xs">
              <div className="bg-slate-50 p-2 rounded-lg space-y-0.5">
                {Object.entries(d.verified_fields || {}).map(([k, v]) => (
                  <div key={k} className="flex justify-between"><span className="text-slate-500">{k}</span><span className={v ? "text-emerald-600 font-bold" : "text-slate-400"}>{v ? "YES" : "NO"}</span></div>
                ))}
              </div>
              <div className="bg-amber-50 p-2 rounded-lg border border-amber-100">
                <p className="font-bold text-amber-800 mb-1">Trigger</p>
                <p className="text-amber-900">{d.trigger_signal || "No verified trigger identified."}</p>
              </div>
              <div className="bg-slate-50 p-2 rounded-lg">
                <p className="font-bold text-slate-600 mb-1">Research completeness / relevance</p>
                <p>{d.research_completeness} / {d.sales_relevance}</p>
              </div>
            </div>

            {d.lead_reason && <p className="text-sm text-slate-700"><span className="font-bold">Why call:</span> {d.lead_reason}</p>}

            {d.decision_maker_name && (
              <p className="text-sm">👤 {d.decision_maker_name} — {d.decision_maker_title} <span className="text-xs text-slate-400">[{d.decision_maker_verification}]</span> {d.decision_maker_contact && `· ${d.decision_maker_contact}`}</p>
            )}

            {d.sources?.length > 0 && (
              <div className="text-xs space-x-2">
                <span className="font-bold text-slate-500">Sources:</span>
                {d.sources.map((s, i) => <a key={i} href={s.url} target="_blank" rel="noreferrer" className="text-blue-600 underline">{s.title}</a>)}
              </div>
            )}

            <div className="flex gap-2 pt-1">
              {d.website && <a href={d.website.startsWith("http") ? d.website : `https://${d.website}`} target="_blank" rel="noreferrer" className="text-xs bg-slate-800 text-white px-3 py-1.5 rounded-lg font-bold">🌐 Website</a>}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
