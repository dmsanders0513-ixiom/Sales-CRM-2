export type CategoryType = "SME" | "Corporate" | "Education" | "Close Network" | "Business Partners";
export type SalesStage = "New" | "Contacted" | "Qualifying" | "Meeting Booked" | "Proposal Sent" | "Negotiation" | "Won" | "Lost" | "Not Qualified";
export type DiscoveryStatus = "NEW" | "REVIEW" | "QUALIFIED" | "REJECTED" | "PROMOTED" | "DUPLICATE";
export type ConfidenceLevel = "LOW" | "MEDIUM" | "HIGH";

export interface Prospect {
  id: string;
  company_name: string;
  trading_name?: string | null;
  category: CategoryType;
  industry?: string | null;
  region?: string | null;
  address?: string | null;
  website?: string | null;
  telephone?: string | null;
  general_email?: string | null;
  decision_maker_name?: string | null;
  decision_maker_title?: string | null;
  decision_maker_email?: string | null;
  decision_maker_phone?: string | null;
  source?: string | null;
  lead_reason?: string | null;
  current_supplier?: string | null;
  current_equipment?: string | null;
  contract_lease_info?: string | null;
  contract_renewal_date?: string | null;
  last_contact_date?: string | null;
  next_followup_date?: string | null;
  next_followup_type?: string | null;
  sales_stage: SalesStage;
  notes?: string | null;
  estimated_opportunity?: number | null;
  probability?: number | null;
  manually_prioritised: boolean;
  discovery_id?: string | null;
  created_at: string;
  updated_at: string;
}

export interface Discovery {
  id: string;
  company_name: string;
  industry?: string | null;
  category: CategoryType;
  region?: string | null;
  website?: string | null;
  address?: string | null;
  company_size_estimate?: string | null;
  decision_maker_name?: string | null;
  decision_maker_title?: string | null;
  decision_maker_contact?: string | null;
  decision_maker_verification: "VERIFIED" | "INFERRED" | "UNKNOWN";
  lead_reason?: string | null;
  trigger_signal?: string | null;
  verified_fields: Record<string, boolean>;
  research_completeness: ConfidenceLevel;
  sales_relevance: ConfidenceLevel;
  verified_facts: string[];
  inferences: string[];
  sources: { url: string; title: string; extractedEvidence: string }[];
  ai_notes?: string | null;
  status: DiscoveryStatus;
  agent_run_id?: string | null;
  date_discovered: string;
  updated_at: string;
}

export interface AgentRun {
  id: string;
  target_category?: string | null;
  target_region?: string | null;
  target_industry?: string | null;
  target_company_size?: string | null;
  requested_lead_count?: number | null;
  status: "running" | "completed" | "failed";
  searches_performed: number;
  candidates_found: number;
  candidates_deep_researched: number;
  leads_qualified: number;
  log: { ts: string; message: string }[];
  started_at: string;
  finished_at?: string | null;
}
